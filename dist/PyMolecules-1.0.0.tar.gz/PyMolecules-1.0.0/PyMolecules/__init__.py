from PyMolecules import SingleLinkedList


__author__ = "Yokesh Bollineni"
__version__ = "1.0.0"
__what_is_new__ = "Added DLL class which has more optimized implementation of methods when compare to SLL"
