from PyMolecules import SingleLinkedList


__author__ = "Yokesh Bollineni"
__version__ = "0.1.1"
__what_is_new__ = "Bug fixes in SLL class of version 0.1.0, Added new __str__ method for SLL"

