from PyMolecules import SingleLinkedList, DoubleLinkedList,SingleCircularLinkedList


__author__ = "Yokesh Bollineni"
__version__ = "2.0.1"
__what_is_new__ = "Added SCLL class, Bug fix in size() method of DLL class"
