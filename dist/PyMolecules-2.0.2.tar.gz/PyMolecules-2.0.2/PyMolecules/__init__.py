from PyMolecules import SingleLinkedList, DoubleLinkedList,SingleCircularLinkedList


__author__ = "Yokesh Bollineni"
__version__ = "2.0.2"
__what_is_new__ = "Removal of junk code in the version 2.0.1"
