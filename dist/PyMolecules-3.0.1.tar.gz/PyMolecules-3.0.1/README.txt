PyMolecules package has 4 classes that can be used as alternative to arrays
PyMolecules are implemented using linkedlist classes and their most common methods like insertion, deletion, searching, sorting etc
